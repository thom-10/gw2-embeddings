<?php

require_once GW2embeddings_Snip::$plugin_path . 'includes/shortcodes/function_amulets.php';
require_once GW2embeddings_Snip::$plugin_path . 'includes/shortcodes/function_items.php';
require_once GW2embeddings_Snip::$plugin_path . 'includes/shortcodes/function_skills.php';
require_once GW2embeddings_Snip::$plugin_path . 'includes/shortcodes/function_specs.php';
require_once GW2embeddings_Snip::$plugin_path . 'includes/shortcodes/function_traits.php';
