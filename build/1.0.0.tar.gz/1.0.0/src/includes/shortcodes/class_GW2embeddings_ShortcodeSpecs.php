<?php
/**
 *  specializations embedding contructor class
 *  (i know. extremly exciting ;-)
 */

class GW2embeddings_ShortcodeSpecs extends GW2embeddings_ShortcodeDefault
{
    // primary attributes
    protected $filter_array_prim = array(
      'id' => '',
      );

    // secondary attributes
    protected $filter_array_sec = array(
      'traits' => '',
      );
}
